const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs'); // To read the JSON file


// Assuming you have already initialized and configured express-openid-connect middleware.
// Make sure you have something like the following in your app setup:
// const { auth } = require('express-openid-connect');
// app.use(auth({...options}));

// Static files setup
router.use(express.static(path.join(__dirname, 'public')));

// Serve static files from the 'Dummy_Database' directory
router.use('/Dummy_Database', express.static(path.join(__dirname, '..', '..', 'Dummy_Database')));

router.get('/', (req, res) => {
  // Check if the user is authenticated
  const isAuthenticated = req.oidc.isAuthenticated();

  if (isAuthenticated) {
    // Check if user object exists before accessing its properties
    const userName = req.oidc.user ? req.oidc.user.name : 'Unknown User';
    console.log('User is authenticated:', userName);
    res.render('home', {
      title: 'Home',
      isAuthenticated: true,
      userName: userName
    });
  } else {
    console.log('User is not authenticated');
    res.render('home', {
      title: 'Home',
      isAuthenticated: false,
      userName: null
    });
  }
});

// Path: Auth0/views/home.ejs

// New route for drill_library page
router.get('/drill_library', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  // Read the drills data from the JSON file
  fs.readFile(path.join(__dirname, "../../Dummy_Database/dummy_drills.json"), "utf8", (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).send("Error reading drill data");
      return;
    }

    const drills = JSON.parse(data);
    res.render("drill_library", { 
      title: 'Drill Library',
      isAuthenticated,
      userName: req.oidc.user ? req.oidc.user.name : 'Unknown User',
      drills
    }); // Pass the drills to the EJS template
  });
});

// import { expandDrill } from '../public/js/expand_drill.js'; // Assuming 'expand_drill.js' is in the same directory

// Path: Auth0/views/drill_library.ejs

// New route for practice_plan page
router.get('/practice_plans', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  // Read the practice plan data from the JSON file
  fs.readFile(path.join(__dirname, "../../Dummy_Database/dummy_practice_plans.json"), "utf8", (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).send("Error reading practice plan data");
      return;
    }

    if (isAuthenticated) {
      // Check if user object exists before accessing its properties
      const userName = req.oidc.user ? req.oidc.user.name : 'Unknown User';
      console.log('User is authenticated:', userName);
      res.render('practice_plans', {
        title: 'Practice Plans',
        isAuthenticated: true,
        userName: userName,
        practicePlanData: JSON.parse(data)
      });
    }
    else {
      res.redirect('/login/');
    }
  });
});

// Path: Auth0/views/practice_plans.ejs

// Route for create_drill page
router.get('/create_drill', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  if (isAuthenticated) {
    res.render("create_drill", { 
    title: 'Create Drill',
    isAuthenticated,
    userName: req.oidc.user ? req.oidc.user.name : 'Unknown User'
  });
  } else {
    res.redirect('/login/');
  }
});

// Path: Auth0/views/create_drill.ejs

// Route for create_plan page
router.get('/create_plan', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  if (isAuthenticated) {
    res.render("create_plan", { 
    title: 'Create Plan',
    isAuthenticated,
    userName: req.oidc.user ? req.oidc.user.name : 'Unknown User'
  });
  } else {
    res.redirect('/login/');
  }
});

// Path: Auth0/views/create_plan.ejs

// New route to drill page
router.get('/drill_view', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  res.render("drill_view", { 
    title: 'Drill View',
    isAuthenticated,
    userName: req.oidc.user ? req.oidc.user.name : 'Unknown User',
  }); // Pass the drills to the EJS template
});

// Path: Auth0/views/drill_view.ejs


// Route to the share plan page
router.get('/share_plan', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  if (isAuthenticated) {
    res.render("share_plan", { 
    title: 'Share Plan',
    isAuthenticated,
    userName: req.oidc.user ? req.oidc.user.name : 'Unknown User'
  });
  } else {
    res.redirect('/login/');
  }
});

// Path: Auth0/views/share_plan.ejs


// Route to the view plan page
router.get('/view_plan', (req, res) => {
  const isAuthenticated = req.oidc.isAuthenticated();

  res.render("view_plan", { 
    title: 'View Plan',
    isAuthenticated,
    userName: req.oidc.user ? req.oidc.user.name : 'Unknown User',
  }); // Pass the drills to the EJS template
});

module.exports = router;




